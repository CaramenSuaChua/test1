exports.Upload = (req, res) => {

    //To convert xlsx to csv
    var obj = xlsx.parse('./uploads/' + req.file.filename); // parses a file
    var rows = [];
    var writeStr = "";

    //looping through all sheets
    for (var i = 0; i < obj.length; i++) {
        var sheet = obj[i];
        //loop through all rows in the sheet
        for (var j = 0; j < sheet['data'].length; j++) {
            //add the row to the rows array
            rows.push(sheet['data'][j]);
        }
    }
    //creates the csv string to write it to a file
    for (var i = 0; i < rows.length; i++) {
        writeStr += rows[i].join(",") + "\n";
    }
    //writes to a file, but you will presumably send the csv as a
    //response instead
    fs.writeFile('./uploads/' + req.file.filename, writeStr, function (err) {
        if (err) {
            return console.log(err);
        }
        console.log("csv was saved in the current directory!");





        // To add headers in CSV
        var fd = fs.openSync('./uploads/' + req.file.filename, 'a+');
        var data = fs.readFileSync('./uploads/' + req.file.filename); //read existing contents
        var fd = fs.openSync('./uploads/' + req.file.filename, 'w+');
        var buffer = new Buffer('field1\n');

        fs.writeSync(fd, buffer, 0, buffer.length, 0); //write new data
        fs.writeSync(fd, data, 0, data.length, buffer.length); //append old data
        // or fs.appendFile(fd, data);
        fs.close(fd);



        // convert csv into Json
        var Converter = require("csvtojson").Converter;
        var converter = new Converter({});
        converter.fromFile('./uploads/' + req.file.filename, function (err,
            result) {
            if (err) {
                console.log("An Error Has Occured");
                console.log(err);
            }
            var data = result;
            console.log('data=>>>>>>', data);
            return res.status(200).send(data);
        });
    });
}