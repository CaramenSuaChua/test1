var mongoose = require('mongoose');
var express = require('express');
var faker  = require('faker');
var path   = require('path');
var dataModel = require('./models/data');
var XLSX = require('xlsx');
var multer = require('multer')
var bodyParser = require('body-parser')

//connect to db
mongoose.connect('mongodb+srv://ngodung:ngodung3042000@cluster0.maaubuy.mongodb.net/?retryWrites=true&w=majority',
{useNewUrlParser:true, })
.then(()=>console.log('connected to db'))
.catch((err)=>console.log('error in connection',err));

//init app
var app = express();
//set the template engine
app.set('view engine','ejs');

//set the static folder path
app.use(express.static(path.resolve(__dirname,'public')));
app.use(bodyParser.json());  

//default page
app.get('/',(req,res)=>{
    console.log('asdas')
    dataModel.find((err,data)=>{
             if(err){
                console.log(err)
             }else{
                 if(data!=''){
                     res.render('home',{data:''});
                 }else{
                     res.render('home',{data:''});
                 }
             }
    })
});

// // store excel files into one folder
// var storage = multer.diskStorage({
//     destination: function (req, file, cb) {
//         cb(null, __dirname + '/uploads/')
//     },
//     filename: function (req, file, cb) {
//         cb(null, Date.now() + '-' + file.originalname)
//     }
// });
// var upload = multer({
//     storage :storage
// });

// var uploadmulter = upload.single('file');

var multipartUpload = multer({storage: multer.diskStorage({
    destination: function (req, file, callback) { callback(null, __dirname + './uploads');},
    filename: function (req, file, callback) { callback(null, file.fieldname + '-' + Date.now());}})
}).single('file');

// var multipartUpload = Multer({storage: Multer.diskStorage({
//     destination: function (req, file, callback) { callback(null, './uploads');},
//     filename: function (req, file, callback) { callback(null, file.fieldname + '-' + Date.now());}})
// }).single('songUpload');
// app.post('/artists', multipartUpload, (req, resp) => {
//     val originalFileName = req.file.originalname
//     console.log(originalFileName)
// }
// generate fake data using faker and save it in db
app.post('/', multipartUpload, (req,res)=>{
    console.log(req.file);
    var workbook = XLSX.readFile('./uploads/' + req.file);
    var sheet_name_list = workbook.SheetNames;
    var data = XLSX.utils.sheet_to_json(workbook.Sheets[sheet_name_list[0]]);
    console.log(data);
    return res.status(200).send(data);
    res.redirect('/')

});

app.post('/exportdata',(req,res)=>{
    var wb = XLSX.utils.book_new(); //new workbook
    dataModel.find((err,data)=>{
        if(err){
            console.log(err)
        }else{
            var temp = JSON.stringify(data);
            temp = JSON.parse(temp);
            var ws = XLSX.utils.json_to_sheet(temp);
            var down = __dirname+'/public/Import_Contacts_template.xlsx'
           XLSX.utils.book_append_sheet(wb,ws,"sheet1");
           XLSX.writeFile(wb,down);
           res.download(down);
        }
    });
});

var port = process.env.PORT || 5000;
app.listen(port,()=>console.log('server run at '+port));

