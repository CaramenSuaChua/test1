var mongoose = require('mongoose');

var dataSchema = new mongoose.Schema({
    name:{type:String},
    phone: {type:String},
    address: {type:String},
});

module.exports = mongoose.model('data',dataSchema);