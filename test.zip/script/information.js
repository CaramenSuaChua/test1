'use strict'

const gender = document.getElementsByName('gender')
const inputFile = document.getElementById('inputfile');
const inputFileName = document.getElementById('inputfilename')
const inputHobies = document.getElementById('input-hobbies');

const KEY_INFOR = 'dataInfor';
let dataInfor = JSON.parse(getFromStorage(KEY_INFOR)) ?? [];

// let file; 
// inputFile.addEventListener('change', (event) => {
//     console.log(event.target)
//     const fileInput = event.target.files[0];
//     file = fileInput.name
//     console.log(fileInput)
//     inputFileName.textContent = fileInput.name
//     console.log(file)
//     }
// )


function butotnClick() {
    console.log('value: ' + inputFile.value);
    inputFileName.textContent = inputFile.name
    let files = inputFile.files;

    for (let i = 0; i < files.length; i++) {
        console.log('File thứ ' + (i + 1));
        console.log('name: ' + files[i].name);
        console.log('size: ' + files[i].size);
        console.log('type: ' + files[i].type);
    }
}


document.getElementById('btn-complete').addEventListener('click', function (e) {
    e.preventDefault()
    
    butotnClick()
    const dataInfor = {
        inputFile: inputFile.value,
        inputGender: '',
        inputHobies: inputHobies.value
    }

    ////////////kiem tra gioi tinh 
    const checkGender = function () {

        for (let i = 0; i < gender.length; i++) {
            if (gender[i].checked) {
                dataInfor.inputGender = gender[i].value
                console.log('gender', dataInfor.inputGender)
            }
        }
    }
    checkGender(e)
    console.log(dataInfor)
    saveToStorage(KEY_INFOR, JSON.stringify(dataInfor))
    window.location.href = '../pages/profile.html'
})

