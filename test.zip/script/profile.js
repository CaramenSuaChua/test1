'use strict '

const inputName = document.getElementById('newName')
const inputEmail = document.getElementById('newEmail')
const inputPhone = document.getElementById('newPhone')
const inputGender = document.getElementById('newGender')
const inputAddress = document.getElementById('newAddress')
const inputHobbies = document.getElementById('newHobbies')
const inputImage = document.getElementById('newImage');

const KEY_PHONE = 'dataPer';
let dataPer = JSON.parse(getFromStorage(KEY_PHONE)) ?? [];


const KEY_INFOR = 'dataInfor';
let dataInfor = JSON.parse(getFromStorage(KEY_INFOR)) ?? [];

const KEY_ADDRESS = 'dataAddress';
let dataAddress = JSON.parse(getFromStorage(KEY_ADDRESS)) ?? [];

console.log(dataPer)
console.log(dataInfor)
console.log(dataAddress)


inputName.textContent = dataPer.inputFullName 
inputEmail.textContent = dataPer.inputEmail 
inputPhone.textContent = dataPer.inputPhone 
inputGender.textContent = dataInfor.inputGender 
inputHobbies.textContent = dataInfor.inputHobies 
inputImage.src = dataInfor.inputFile
inputAddress.textContent = `${dataAddress.addressStreet }, ${dataAddress.addressTown} ,  ${dataAddress.addressDistrict}, ${dataAddress.addressProvince}   ` 


document.getElementById('home').addEventListener('click', function (e) {
    e.preventDefault()

    window.location.href = '../pages/address.html'
})
